//FYI this isnt ads, its me fooling adblockers.
var canRunAds = true;
